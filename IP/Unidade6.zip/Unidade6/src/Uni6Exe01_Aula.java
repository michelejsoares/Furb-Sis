public class Uni6Exe01_Aula {
    public static void main(String[] args) {
        new Uni6Exe01_Aula();
    }
    private Uni6Exe01_Aula(){
        String nome = "Julia";
        imprimir(nome);
    }
    private void imprimir(String nome) {
        System.out.println("Nome: "+nome);
    }
}
