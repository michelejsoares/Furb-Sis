import java.util.Scanner;

public class UNi2Exe09 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		float valorDolar = 0.0f;
		float valorReal = 0.0f;
		float valorCotacao = 0.0f;

		System.out.println("Informe o valor em dolar:");
		valorDolar = sc.nextFloat();
		System.out.println("Informe a cotação:");
		valorCotacao = sc.nextFloat();

		valorReal = valorDolar * valorCotacao;
		System.out.println("O valor em real é: "+valorReal);
		sc.close();

	}
}
